from Bio import SeqIO

import fasta_read

fasta_sequences = SeqIO.parse(open('sample.fa'), 'fasta')
result = {}
for seq in fasta_sequences:
    result.update({
        seq.name: str(seq.seq)
    })
print(result)
fr = fasta_read.FastaReader('sample.fa')
shared_items = {k: fr[k] for k in fr if k in result and fr[k] == result[k]}
assert len(shared_items) == len(fr)
